"""
Core crawler implementation for Crawel AI Agent.
Based on the AggressiveHCPCrawler but refactored for general domain crawling.
"""

import time
import logging
import threading
from urllib.parse import urlparse, urljoin
from typing import Set, List, Dict, Any, Optional, Tuple

from selenium import webdriver
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.common.exceptions import TimeoutException, NoSuchElementException
from webdriver_manager.chrome import ChromeDriverManager
from bs4 import BeautifulSoup

from config.settings import CrawlerSettings, DomainConfig
from utils.logger import get_logger


logger = get_logger(__name__)


class UniversalCrawler:
    """Universal web crawler that can handle any domain."""
    
    def __init__(self, settings: CrawlerSettings, domain_config: DomainConfig):
        """Initialize the crawler with settings and domain configuration."""
        self.settings = settings
        self.domain_config = domain_config
        self.driver = None
        self.discovered_urls: Set[str] = set()
        self.crawled_urls: Set[str] = set()
        self.content_map: Dict[str, str] = {}
        self.lock = threading.Lock()
        
        logger.info(f"🤖 Initializing Universal Crawler for domain: {domain_config.domain}")
        logger.info(f"📊 Settings: batch_size={settings.batch_size}, max_pages={settings.max_pages}")
    
    def setup_driver(self) -> bool:
        """Setup Chrome WebDriver with optimized options."""
        try:
            chrome_options = Options()
            
            if self.settings.headless:
                chrome_options.add_argument("--headless")
            
            # Performance optimizations
            chrome_options.add_argument("--no-sandbox")
            chrome_options.add_argument("--disable-dev-shm-usage")
            chrome_options.add_argument("--disable-gpu")
            chrome_options.add_argument(f"--window-size={self.settings.window_size[0]},{self.settings.window_size[1]}")
            chrome_options.add_argument("--disable-extensions")
            chrome_options.add_argument("--disable-plugins")
            chrome_options.add_argument("--disable-images")
            chrome_options.add_argument("--disable-web-security")
            chrome_options.add_argument("--allow-running-insecure-content")
            chrome_options.add_argument("--disable-features=VizDisplayCompositor")
            chrome_options.add_argument(f"--user-agent={self.settings.user_agent}")
            
            # Try to create driver
            try:
                service = Service()
                self.driver = webdriver.Chrome(service=service, options=chrome_options)
            except Exception:
                self.driver = webdriver.Chrome(
                    service=Service(ChromeDriverManager().install()), 
                    options=chrome_options
                )
            
            self.driver.set_page_load_timeout(self.settings.page_timeout)
            logger.info("✅ WebDriver setup successful")
            return True
            
        except Exception as e:
            logger.error(f"❌ WebDriver setup failed: {e}")
            return False
    
    def wait_for_spa_content(self, url: str, max_wait: Optional[int] = None) -> bool:
        """Wait for React/SPA content to fully load."""
        max_wait = max_wait or self.settings.spa_wait_timeout
        
        try:
            # Wait for document ready
            WebDriverWait(self.driver, max_wait).until(
                lambda driver: driver.execute_script("return document.readyState") == "complete"
            )
            
            # Multiple strategies to detect content loading
            strategies = [
                # Try domain-specific selectors first
                lambda d: d.find_element(By.CSS_SELECTOR, self.domain_config.content_selectors[0][0]),
                # Fallback to generic strategies
                lambda d: d.find_element(By.TAG_NAME, "main"),
                lambda d: len(d.find_elements(By.TAG_NAME, "a")) > 20,  # Lots of links loaded
                lambda d: len(d.find_elements(By.TAG_NAME, "div")) > 50   # Substantial content
            ]
            
            for strategy in strategies:
                try:
                    WebDriverWait(self.driver, 5).until(strategy)
                    break
                except TimeoutException:
                    continue
            
            # Additional wait for JavaScript execution
            time.sleep(2)
            
            # Handle hash fragments by scrolling/clicking
            if '#' in url:
                self._handle_hash_fragment(url)
            
            return True
            
        except Exception as e:
            logger.warning(f"⚠️ Content load timeout for {url}: {e}")
            return False
    
    def _handle_hash_fragment(self, url: str) -> None:
        """Handle hash fragments in URLs for SPA navigation."""
        fragment = url.split('#')[1]
        try:
            selectors = [
                f"#{fragment}",
                f"[data-testid='{fragment}']",
                f"[aria-label*='{fragment}']",
                f"[title*='{fragment}']"
            ]
            
            for selector in selectors:
                try:
                    element = self.driver.find_element(By.CSS_SELECTOR, selector)
                    self.driver.execute_script("arguments[0].scrollIntoView(true);", element)
                    if element.tag_name.lower() in ['button', 'a']:
                        element.click()
                    time.sleep(1)
                    break
                except NoSuchElementException:
                    continue
        except Exception:
            pass
    
    def normalize_url(self, url: str) -> str:
        """Normalize URL to prevent duplicates."""
        try:
            parsed = urlparse(url)
            path = parsed.path.rstrip('/')
            if not path:
                path = '/'
            
            clean_url = f"{parsed.scheme}://{parsed.netloc}{path}"
            if parsed.query:
                clean_url += f"?{parsed.query}"
            
            # Only keep meaningful fragments
            if parsed.fragment and len(parsed.fragment) > 1 and not parsed.fragment.startswith('_'):
                clean_url += f"#{parsed.fragment}"
                
            return clean_url
        except Exception:
            return url
    
    def extract_all_links(self, base_domain: str) -> Set[str]:
        """Extract all internal links from current page."""
        links = set()
        
        try:
            link_elements = self.driver.find_elements(By.TAG_NAME, "a")
            
            for element in link_elements:
                try:
                    href = element.get_attribute("href")
                    if href:
                        full_url = urljoin(self.driver.current_url, href)
                        parsed = urlparse(full_url)
                        
                        # Only include same domain
                        if parsed.netloc == base_domain:
                            normalized_url = self.normalize_url(full_url)
                            links.add(normalized_url)
                            
                except Exception:
                    continue
            
            logger.debug(f"🔗 Found {len(links)} links on current page")
            return links
            
        except Exception as e:
            logger.error(f"❌ Error extracting links: {e}")
            return set()
    
    def discover_urls(self) -> Set[str]:
        """Discover all URLs using multi-threaded approach."""
        base_domain = urlparse(self.domain_config.base_url).netloc
        
        # Initialize with seed URLs
        seed_urls = set(self.domain_config.seed_urls)
        
        # Add hash routes if available
        if self.domain_config.hash_routes:
            products_base = f"{self.domain_config.base_url}/products"
            for fragment in self.domain_config.hash_routes:
                seed_urls.add(f"{products_base}#{fragment}")
        
        # Add specific routes if available
        for route in self.domain_config.specific_routes:
            seed_urls.add(f"{self.domain_config.base_url}{route}")
        
        self.discovered_urls = seed_urls.copy()
        to_crawl_set = set(seed_urls)
        self.crawled_urls = set()
        
        max_pages = self.settings.max_pages
        max_consecutive_no_new = self.settings.max_consecutive_no_new
        consecutive_no_new_links = [0]
        discovery_count = [0]
        stop_flag = threading.Event()
        queue = list(to_crawl_set)
        queue_lock = threading.Lock()
        
        def worker(thread_id):
            local_driver = None
            try:
                local_driver = self._create_thread_driver()
                
                while not stop_flag.is_set():
                    with queue_lock:
                        if (not queue or 
                            discovery_count[0] >= max_pages or 
                            consecutive_no_new_links[0] >= max_consecutive_no_new):
                            break
                        current_url = queue.pop()
                    
                    with self.lock:
                        if current_url in self.crawled_urls:
                            continue
                        self.crawled_urls.add(current_url)
                        discovery_count[0] += 1
                    
                    logger.info(f"[Thread {thread_id}] 🔍 Discovery {discovery_count[0]}: {current_url}")
                    
                    try:
                        local_driver.get(current_url)
                        if self.wait_for_spa_content(current_url):
                            page_links = self._extract_all_links_threadsafe(local_driver, base_domain)
                            
                            with self.lock:
                                new_links = page_links - self.discovered_urls - self.crawled_urls
                                if new_links:
                                    for link in new_links:
                                        self.discovered_urls.add(link)
                                        with queue_lock:
                                            queue.append(link)
                                    consecutive_no_new_links[0] = 0
                                    logger.info(f"[Thread {thread_id}] 📈 Found {len(new_links)} new URLs")
                                else:
                                    consecutive_no_new_links[0] += 1
                        
                        time.sleep(self.settings.request_delay)
                        
                    except Exception as e:
                        logger.error(f"[Thread {thread_id}] ❌ Discovery error for {current_url}: {e}")
                        continue
                        
            finally:
                if local_driver:
                    local_driver.quit()
        
        # Start worker threads
        threads = []
        for i in range(self.settings.threads):
            t = threading.Thread(target=worker, args=(i+1,))
            threads.append(t)
            t.start()
        
        # Wait for completion
        for t in threads:
            t.join()
        
        logger.info(f"🎉 Discovery completed! Found {len(self.discovered_urls)} URLs")
        return self.discovered_urls
    
    def _create_thread_driver(self):
        """Create a new WebDriver instance for a thread."""
        chrome_options = Options()
        if self.settings.headless:
            chrome_options.add_argument("--headless")
        chrome_options.add_argument("--no-sandbox")
        chrome_options.add_argument("--disable-dev-shm-usage")
        chrome_options.add_argument("--disable-gpu")
        chrome_options.add_argument(f"--window-size={self.settings.window_size[0]},{self.settings.window_size[1]}")
        chrome_options.add_argument("--disable-extensions")
        chrome_options.add_argument("--disable-plugins")
        chrome_options.add_argument("--disable-images")
        chrome_options.add_argument(f"--user-agent={self.settings.user_agent}")
        
        try:
            service = Service()
            driver = webdriver.Chrome(service=service, options=chrome_options)
        except Exception:
            driver = webdriver.Chrome(service=Service(ChromeDriverManager().install()), options=chrome_options)
        
        driver.set_page_load_timeout(self.settings.page_timeout)
        return driver
    
    def _extract_all_links_threadsafe(self, driver, base_domain: str) -> Set[str]:
        """Thread-safe link extraction."""
        links = set()
        try:
            link_elements = driver.find_elements(By.TAG_NAME, "a")
            for element in link_elements:
                try:
                    href = element.get_attribute("href")
                    if href:
                        full_url = urljoin(driver.current_url, href)
                        parsed = urlparse(full_url)
                        if parsed.netloc == base_domain:
                            normalized_url = self.normalize_url(full_url)
                            links.add(normalized_url)
                except Exception:
                    continue
            return links
        except Exception:
            return set()
    
    def extract_content(self, url: str) -> Dict[str, Any]:
        """Extract content from a URL."""
        try:
            page_source = self.driver.page_source
            soup = BeautifulSoup(page_source, 'html.parser')
            
            # Try domain-specific content selectors
            content = None
            for selector, description in self.domain_config.content_selectors:
                try:
                    elements = soup.select(selector)
                    for element in elements:
                        text = element.get_text(strip=True)
                        if text and len(text) > self.settings.min_content_length:
                            content = text
                            break
                except Exception:
                    continue
                
                if content:
                    break
            
            # Extract media if enabled
            image_paths = []
            video_paths = []
            
            if self.settings.extract_images or self.settings.extract_videos:
                for selector, _ in self.domain_config.content_selectors:
                    try:
                        elements = soup.select(selector)
                        for element in elements:
                            if self.settings.extract_images:
                                imgs = element.find_all('img')
                                for img in imgs:
                                    src = img.get('src')
                                    if src:
                                        image_paths.append(urljoin(url, src))
                            
                            if self.settings.extract_videos:
                                videos = element.find_all('video')
                                for vid in videos:
                                    src = vid.get('src')
                                    if src:
                                        video_paths.append(urljoin(url, src))
                    except Exception:
                        continue
            
            # Get page title
            page_title = soup.title.string if soup.title else f"Page from {self.domain_config.domain}"
            
            result = {
                'url': url,
                'title': page_title,
                'content': content if content else '',
                'image_paths': image_paths,
                'video_paths': video_paths,
                'success': bool(content),
                'content_length': len(content) if content else 0
            }
            
            return result
            
        except Exception as e:
            logger.error(f"❌ Content extraction error for {url}: {e}")
            return {
                'url': url,
                'title': f"Error from {self.domain_config.domain}",
                'content': '',
                'image_paths': [],
                'video_paths': [],
                'success': False,
                'error': str(e)
            }
    
    def crawl_discovered_urls(self, urls: List[str]) -> List[Dict[str, Any]]:
        """Crawl a list of URLs and extract content."""
        results = []
        visited = set()
        
        for i, url in enumerate(urls):
            if url in visited:
                continue
            visited.add(url)
            
            if i % 10 == 0:
                logger.info(f"📈 Progress: {i+1}/{len(urls)} ({((i+1)/len(urls)*100):.1f}%)")
            
            logger.info(f"[{i+1}/{len(urls)}] Crawling: {url}")
            
            try:
                self.driver.get(url)
                if self.wait_for_spa_content(url):
                    result = self.extract_content(url)
                    results.append(result)
                    
                    if result['success']:
                        logger.debug(f"✅ Successfully extracted content from: {url}")
                    else:
                        logger.warning(f"⚠️ No content found for: {url}")
                else:
                    logger.warning(f"⚠️ SPA content not loaded for: {url}")
                
                time.sleep(self.settings.request_delay)
                
            except Exception as e:
                logger.error(f"❌ Failed to crawl {url}: {e}")
                results.append({
                    'url': url,
                    'title': f"Error from {self.domain_config.domain}",
                    'content': '',
                    'image_paths': [],
                    'video_paths': [],
                    'success': False,
                    'error': str(e)
                })
        
        logger.info(f"✅ Crawling completed. Processed {len(results)} URLs")
        return results
    
    def cleanup(self):
        """Clean up resources."""
        if self.driver:
            try:
                self.driver.quit()
                logger.info("🔧 WebDriver closed successfully")
            except Exception as e:
                logger.error(f"❌ Error closing WebDriver: {e}")
