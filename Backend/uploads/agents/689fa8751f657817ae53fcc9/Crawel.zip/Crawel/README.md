# Crawel - AI Web Crawler Agent

An intelligent web crawling agent that takes domain names as input and delivers comprehensive batch files for web crawling.

## Features

- **Domain-based Crawling**: Input any domain name to start crawling
- **Intelligent Discovery**: Uses multiple strategies to discover all available URLs
- **Batch Processing**: Generates organized batch files for efficient processing
- **SPA Support**: Handles Single Page Applications and dynamic content
- **Multi-threaded**: Concurrent crawling for better performance
- **Configurable**: Extensive configuration options for different use cases
- **Resilient**: Built-in error handling and retry mechanisms

## Quick Start

```bash
# Install dependencies
pip install -r requirements.txt

# Run the agent
python main.py --domain "docs.hcp.uhg.com"

# Or use the interactive mode
python main.py --interactive
```

## Project Structure

```
Crawel/
├── main.py                 # Main entry point
├── config/
│   ├── __init__.py
│   ├── settings.py         # Configuration settings
│   └── domains.yaml        # Domain-specific configurations
├── core/
│   ├── __init__.py
│   ├── crawler.py          # Core crawler logic
│   ├── discovery.py        # URL discovery engine
│   └── extractor.py        # Content extraction engine
├── agents/
│   ├── __init__.py
│   ├── crawler_agent.py    # Main crawler agent
│   └── batch_agent.py      # Batch processing agent
├── utils/
│   ├── __init__.py
│   ├── helpers.py          # Utility functions
│   ├── validators.py       # Input validation
│   └── logger.py           # Logging configuration
├── tests/
│   ├── __init__.py
│   ├── test_crawler.py
│   └── test_agents.py
├── output/                 # Generated batch files
├── logs/                   # Log files
└── requirements.txt
```

## Configuration

The agent can be configured through:
- Command line arguments
- Configuration files (`config/settings.py`)
- Domain-specific settings (`config/domains.yaml`)

## Output

The agent generates:
- **Discovery Files**: JSON files with all discovered URLs
- **Batch Files**: Organized content batches ready for processing
- **Metadata Files**: Crawling statistics and metadata
- **Error Reports**: Failed URLs and error analysis

## Examples

```python
from agents.crawler_agent import CrawlerAgent

# Initialize agent
agent = CrawlerAgent()

# Crawl a domain
results = agent.crawl_domain("example.com")

# Generate batch files
agent.generate_batches(batch_size=500)
```

## License

MIT License
