"""Configuration module for Crawel AI Crawler Agent."""
