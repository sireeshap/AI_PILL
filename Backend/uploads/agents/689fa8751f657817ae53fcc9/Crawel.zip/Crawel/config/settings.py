"""
Configuration settings for the Crawel AI Crawler Agent.
"""

import os
from dataclasses import dataclass, field
from typing import List, Dict, Any, Optional
from pathlib import Path


@dataclass
class CrawlerSettings:
    """Main configuration settings for the crawler."""
    
    # Basic settings
    batch_size: int = 500
    max_pages: int = 1000
    max_concurrent_threads: int = 4
    headless: bool = True
    
    # Timeouts and delays
    page_timeout: int = 30
    spa_wait_timeout: int = 20
    request_delay: float = 1.5
    
    # Discovery settings
    max_consecutive_no_new: int = 20
    discovery_only: bool = False
    
    # Output settings
    output_dir: str = "output"
    logs_dir: str = "logs"
    save_checkpoint: bool = True
    checkpoint_interval: int = 100
    
    # Browser settings
    user_agent: str = "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36"
    window_size: tuple = (1920, 1080)
    
    # Content extraction settings
    min_content_length: int = 100
    extract_images: bool = True
    extract_videos: bool = True
    
    # Threading settings
    threads: int = 4
    
    def __post_init__(self):
        """Post-initialization setup."""
        # Ensure output directories exist
        Path(self.output_dir).mkdir(parents=True, exist_ok=True)
        Path(self.logs_dir).mkdir(parents=True, exist_ok=True)


@dataclass
class DomainConfig:
    """Domain-specific configuration."""
    
    domain: str
    base_url: str
    seed_urls: List[str] = field(default_factory=list)
    hash_routes: List[str] = field(default_factory=list)
    specific_routes: List[str] = field(default_factory=list)
    
    # Content selectors (CSS selectors for content extraction)
    content_selectors: List[tuple] = field(default_factory=lambda: [
        ('div[data-cy="center-content"]', 'main content area'),
        ('.chakra-tabs__tab-panel[aria-hidden="false"]', 'active tab panel'),
        ('.chakra-tabs__tab-panel', 'tab panel'),
        ('main', 'main element'),
        ('article', 'article element'),
        ('[role="main"]', 'main role'),
        ('body', 'body fallback')
    ])
    
    # Custom settings for this domain
    custom_settings: Dict[str, Any] = field(default_factory=dict)


# Predefined domain configurations
DOMAIN_CONFIGS = {
    "docs.hcp.uhg.com": DomainConfig(
        domain="docs.hcp.uhg.com",
        base_url="https://docs.hcp.uhg.com",
        seed_urls=[
            "https://docs.hcp.uhg.com",
            "https://docs.hcp.uhg.com/products",
            "https://docs.hcp.uhg.com/technologies",
            "https://docs.hcp.uhg.com/best-practices",
            "https://docs.hcp.uhg.com/public-cloud",
            "https://docs.hcp.uhg.com/console-builder-&-developer-guide"
        ],
        hash_routes=[
            "compute", "artificial-intelligence", "business-applications",
            "content-management", "database", "data-management", 
            "end-user-software", "engineering-tools", "experience-and-marketing-technologies",
            "geospatial-technology", "internet-of-things", "networking",
            "operations-management", "organizational-support", "public-cloud",
            "security-identity-and-compliance", "services", "storage"
        ],
        specific_routes=[
            "/public-cloud/azure-request-services-in-private-marketplace",
            "/public-cloud/azure-aks-user-guide", 
            "/public-cloud/aws-ecr-cleanup",
            "/public-cloud/aws-remove-ports-from-a-security-group",
            "/public-cloud/create-a-non-production-cloud-account",
            "/console-builder-&-developer-guide/getting-started"
        ]
    )
}


def get_domain_config(domain: str) -> DomainConfig:
    """Get configuration for a specific domain."""
    if domain in DOMAIN_CONFIGS:
        return DOMAIN_CONFIGS[domain]
    
    # Create default configuration for unknown domains
    base_url = f"https://{domain}" if not domain.startswith(('http://', 'https://')) else domain
    if base_url.endswith('/'):
        base_url = base_url[:-1]
    
    return DomainConfig(
        domain=domain,
        base_url=base_url,
        seed_urls=[base_url]
    )


def update_domain_config(domain: str, config_updates: Dict[str, Any]) -> None:
    """Update configuration for a domain."""
    if domain not in DOMAIN_CONFIGS:
        DOMAIN_CONFIGS[domain] = get_domain_config(domain)
    
    config = DOMAIN_CONFIGS[domain]
    for key, value in config_updates.items():
        if hasattr(config, key):
            setattr(config, key, value)


# Environment-based settings
DEBUG = os.getenv("CRAWEL_DEBUG", "false").lower() == "true"
LOG_LEVEL = os.getenv("CRAWEL_LOG_LEVEL", "INFO").upper()
OUTPUT_BASE_DIR = os.getenv("CRAWEL_OUTPUT_DIR", "output")
LOGS_BASE_DIR = os.getenv("CRAWEL_LOGS_DIR", "logs")
