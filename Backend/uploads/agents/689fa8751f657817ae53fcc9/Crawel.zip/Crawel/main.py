#!/usr/bin/env python3
"""
Crawel - AI Web Crawler Agent
Main entry point for the crawler agent system.
"""

import argparse
import sys
import logging
from pathlib import Path

# Add project root to path
project_root = Path(__file__).parent
sys.path.insert(0, str(project_root))

from utils.logger import setup_logger
from agents.crawler_agent import CrawlerAgent
from config.settings import CrawlerSettings
from utils.validators import validate_domain


def parse_arguments():
    """Parse command line arguments."""
    parser = argparse.ArgumentParser(
        description="Crawel - AI Web Crawler Agent",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  %(prog)s --domain "docs.hcp.uhg.com"
  %(prog)s --domain "example.com" --batch-size 1000 --headless
  %(prog)s --interactive
  %(prog)s --config config/custom.yaml
        """
    )
    
    parser.add_argument(
        "--domain", "-d",
        type=str,
        help="Domain name to crawl (e.g., 'docs.hcp.uhg.com')"
    )
    
    parser.add_argument(
        "--batch-size", "-b",
        type=int,
        default=500,
        help="Number of URLs per batch file (default: 500)"
    )
    
    parser.add_argument(
        "--max-pages", "-m",
        type=int,
        default=1000,
        help="Maximum number of pages to crawl (default: 1000)"
    )
    
    parser.add_argument(
        "--threads", "-t",
        type=int,
        default=4,
        help="Number of concurrent threads (default: 4)"
    )
    
    parser.add_argument(
        "--headless",
        action="store_true",
        help="Run browser in headless mode"
    )
    
    parser.add_argument(
        "--interactive", "-i",
        action="store_true",
        help="Run in interactive mode"
    )
    
    parser.add_argument(
        "--config", "-c",
        type=str,
        help="Path to configuration file"
    )
    
    parser.add_argument(
        "--output-dir", "-o",
        type=str,
        default="output",
        help="Output directory for batch files (default: output)"
    )
    
    parser.add_argument(
        "--verbose", "-v",
        action="store_true",
        help="Enable verbose logging"
    )
    
    parser.add_argument(
        "--discovery-only",
        action="store_true",
        help="Only perform URL discovery, skip content extraction"
    )
    
    return parser.parse_args()


def interactive_mode():
    """Run the agent in interactive mode."""
    print("\n🤖 Welcome to Crawel - AI Web Crawler Agent")
    print("=" * 50)
    
    while True:
        try:
            domain = input("\nEnter domain name to crawl (or 'quit' to exit): ").strip()
            
            if domain.lower() in ['quit', 'exit', 'q']:
                print("👋 Goodbye!")
                break
                
            if not domain:
                print("❌ Please enter a valid domain name")
                continue
                
            # Validate domain
            if not validate_domain(domain):
                print(f"❌ Invalid domain format: {domain}")
                continue
                
            # Get additional options
            print("\n📋 Configuration Options:")
            batch_size = input("Batch size (default 500): ").strip() or "500"
            max_pages = input("Max pages (default 1000): ").strip() or "1000"
            headless = input("Headless mode? (y/N): ").strip().lower() in ['y', 'yes']
            
            try:
                batch_size = int(batch_size)
                max_pages = int(max_pages)
            except ValueError:
                print("❌ Invalid numeric values, using defaults")
                batch_size = 500
                max_pages = 1000
                
            # Run the crawler
            print(f"\n🚀 Starting crawl for domain: {domain}")
            run_crawler(domain, batch_size, max_pages, headless, interactive=True)
            
        except KeyboardInterrupt:
            print("\n\n👋 Interrupted by user. Goodbye!")
            break
        except Exception as e:
            print(f"❌ Error: {e}")


def run_crawler(domain, batch_size=500, max_pages=1000, headless=True, 
                threads=4, output_dir="output", discovery_only=False, interactive=False):
    """Run the crawler with specified parameters."""
    
    logger = logging.getLogger(__name__)
    
    try:
        # Initialize settings
        settings = CrawlerSettings(
            batch_size=batch_size,
            max_pages=max_pages,
            headless=headless,
            threads=threads,
            output_dir=output_dir,
            discovery_only=discovery_only
        )
        
        # Initialize and run crawler agent
        agent = CrawlerAgent(settings)
        
        logger.info(f"🚀 Starting crawl for domain: {domain}")
        print(f"🚀 Starting crawl for domain: {domain}")
        
        # Run the crawling process
        results = agent.crawl_domain(domain)
        
        if results:
            logger.info("✅ Crawling completed successfully")
            print("✅ Crawling completed successfully")
            
            # Display results summary
            print(f"\n📊 Crawling Summary:")
            print(f"   • URLs discovered: {results.get('urls_discovered', 0)}")
            print(f"   • URLs crawled: {results.get('urls_crawled', 0)}")
            print(f"   • Batch files generated: {results.get('batch_files', 0)}")
            print(f"   • Output directory: {results.get('output_dir', 'output')}")
            
            if not interactive:
                print(f"\n📁 Check the '{output_dir}' directory for generated batch files")
        else:
            logger.error("❌ Crawling failed")
            print("❌ Crawling failed - check logs for details")
            
    except Exception as e:
        logger.error(f"❌ Crawler execution failed: {e}", exc_info=True)
        print(f"❌ Error: {e}")
        if not interactive:
            sys.exit(1)


def main():
    """Main entry point."""
    args = parse_arguments()
    
    # Setup logging
    log_level = logging.DEBUG if args.verbose else logging.INFO
    setup_logger(log_level)
    
    logger = logging.getLogger(__name__)
    logger.info("🤖 Crawel AI Crawler Agent starting...")
    
    # Run in interactive mode
    if args.interactive:
        interactive_mode()
        return
    
    # Validate required arguments
    if not args.domain:
        print("❌ Error: Domain name is required")
        print("Use --help for usage information")
        sys.exit(1)
    
    # Validate domain
    if not validate_domain(args.domain):
        print(f"❌ Error: Invalid domain format: {args.domain}")
        sys.exit(1)
    
    # Run crawler with provided arguments
    run_crawler(
        domain=args.domain,
        batch_size=args.batch_size,
        max_pages=args.max_pages,
        headless=args.headless,
        threads=args.threads,
        output_dir=args.output_dir,
        discovery_only=args.discovery_only
    )


if __name__ == "__main__":
    main()
